const CustomError = class CustomError {
  constructor( attrs ) {
    Object.assign( this, attrs );
  }
};

module.exports = CustomError;
